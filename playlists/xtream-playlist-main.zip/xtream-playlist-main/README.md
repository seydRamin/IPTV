# Xtream playlist

This is an M3U8 playlist and Xtream playlist for free channels around the World.

Using IPTV M3u8 links in 2024 is an excellent way to enhance your TV viewing experience. With these links, you can easily access TV shows, movies, series, and sports games streaming by simply using an M3u8 playlist url or Xtream url.

![VLC Network Panel](https://raw.githubusercontent.com/m3u8-xtream/magazine-blog/master/img/preview.jpg)

# Format

Example of code:

```
Host: http://network.com:1400
Username: grop123
Password: ciksi3
```

# Source

It can be quite hard to find up to date URLs, here's a list of sources:

- Youtube: As long as the channel is live and its URL doesn't change
- Dailymotion: Same criteria as for youtube.

# Playlist

The M3u8 and Xtream playlist on free channels:

```
Host: http://138.255.102.3:25461/
Username: FOXSPORTS1HDsd
Password: RRZKamZw9a
```

```
Host: http://7go.xyz:8080/
Username: 15junior
Password: as1266375
```

```
Host: http://6oclock.xyz/
Username: oVTsSvYjZu
Password: cAXDNm9LY9
```

```
Host: http://onlinetv365.xyz:8080/
Username: 57tyjhg65ljouni7yu711
Password: thjhg3468ihj
```

```
Host: https://mainsrv.contentgftp.xyz/
Username: Geraldo
Password: 12345678
```

```
Host: http://2hubs.ddns.net:25461/
Username: Faucon1tvMT
Password: g8pHKUYxwDhx
```

```
Host: http://sport.xphost19.xyz:2082/
Username: Jvyct679999967DDDF4477
Password: Xpluxxx3333ggghy5t57
```

```
Host: http://iptv.icsnleb.com:25461/
Username: 12
Password: 12
```

```
Host: http://138.255.102.3:25461/
Username: FOXSPORTS1HDsd
Password: RRZKamZw9a
```

```
Host/url: https://voz.one/
Username: alexfnt
Password: vTFBGKdUYq
```

```
Host/url: http://138.255.102.3:25461/
Username: FOXSPORTS1HDsd
Password: RRZKamZw9a
```

# Issues

Only create issues for bugs and feature requests.

Do not create issues to add/edit or to remove channels. If you want to add/edit/remove channels, create a pull request directly.
